USE [BDHIS_MINSA];
SET LANGUAGE SPANISH;

SELECT
    -- IIF(ME.MICRORED ='NO PERTENECE A NINGUNA MICRORED', 'HOSPITAL', ME.MICRORED) AS [MICRORED],
    ME.MicroRed AS [MICRORED],
	ME.Nombre_Establecimiento AS [ESTABLECIMIENTO],
	N.ANIO as A�O,
    DATENAME(MONTH, CAST('01/'+N.MES+'/2020' AS DATE)) AS 'MES',
    N.CODIGO_ITEM AS CIEX,
    CX.Descripcion_Item AS DESCRIPCION,
    ISNULL(N.VALOR_LAB,'') AS LAB,
    COUNT(*) AS TOTAL
FROM
    T_CONSOLIDADO_NUEVA_TRAMA_HISMINSA AS N
    INNER JOIN MAESTRO_HIS_CIE_CPMS AS CX ON N.Codigo_Item = CX.Codigo_Item
    INNER JOIN MAESTRO_HIS_ESTABLECIMIENTO AS ME ON N.Id_Establecimiento = ME.Id_Establecimiento    
WHERE    
	N.CODIGO_ITEM = '98967'
	AND N.ANIO='2021' AND N.Mes='12'
    /*((LEFT(N.CODIGO_ITEM, 3) IN ('F19') OR N.CODIGO_ITEM IN ('F100', 'F101'))
    OR N.VALOR_LAB = 'AD')    
    AND N.ANIO = 2020*/
GROUP BY
    N.ANIO,
    N.MES,    
    ME.MICRORED,
    ME.Nombre_Establecimiento,
    N.CODIGO_ITEM,
    CX.Descripcion_Item,
    N.VALOR_LAB
ORDER BY
    ME.MICRORED,
    ME.Nombre_Establecimiento,
    N.ANIO,
    N.MES,
    N.CODIGO_ITEM,
    CX.Descripcion_Item,
    N.VALOR_LAB